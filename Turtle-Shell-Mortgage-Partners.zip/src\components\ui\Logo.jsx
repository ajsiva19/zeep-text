export function TurtleIcon({ className = "w-10 h-10" }) {
  return (
    <svg viewBox="0 0 64 64" fill="none" className={className} aria-hidden="true">
      <path
        d="M32 8L44 20L32 32L20 20L32 8Z"
        stroke="currentColor"
        strokeWidth="1.5"
        fill="none"
      />
      <path
        d="M32 32L44 44L32 56L20 44L32 32Z"
        stroke="currentColor"
        strokeWidth="1.5"
        fill="none"
      />
      <path d="M32 8V32V56" stroke="currentColor" strokeWidth="1.5" />
      <path d="M20 20L32 32L44 20" stroke="currentColor" strokeWidth="1.5" />
      <path d="M20 44L32 32L44 44" stroke="currentColor" strokeWidth="1.5" />
      <path d="M8 32H20M44 32H56" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      <path d="M12 24L20 20M52 24L44 20M12 40L20 44M52 40L44 44" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
}

export function Logo({ variant = "light", showTagline = false, className = "" }) {
  const textColor = variant === "light" ? "text-white" : "text-navy-950";
  const goldColor = "text-gold-400";

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <img src="/logo.png" alt="Turtle Shell Mortgage Partners" className="h-10 w-10 object-contain" />
      <div className="text-left leading-tight">
        <div className={`text-xs font-bold tracking-wider ${goldColor}`}>TURTLE SHELL</div>
        <div className={`text-[10px] font-semibold tracking-widest ${variant === "light" ? "text-white/90" : "text-navy-800"}`}>
          MORTGAGE PARTNERS
        </div>
        {showTagline && (
          <div className={`text-[8px] tracking-widest mt-0.5 ${goldColor}`}>
            YOUR DESTINY, BY YOUR OWN DESIGN
          </div>
        )}
      </div>
    </div>
  );
}
