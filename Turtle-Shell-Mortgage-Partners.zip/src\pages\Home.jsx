import { motion } from "framer-motion";
import { Play, Home, RefreshCw, TrendingUp, Key, Shield, BarChart3, UserCheck } from "lucide-react";
import { Button } from "../components/ui/Button";
import { SectionHeading } from "../components/ui/SectionHeading";
import { CTABanner, CTASection } from "../components/ui/CTABanner";
import { ServiceCard, GoalCard, FeatureItem, StepCard, ValueCard } from "../components/ui/Cards";
import {
  HERO_IMAGE,
  FAMILY_IMAGE,
  homeGoals,
  whyChooseFeatures,
  howItWorksSteps,
  mortgageSolutions,
  turtleValues,
} from "../data/content";

const iconMap = { Home, Key, RefreshCw, TrendingUp };

const fadeUp = {
  initial: { opacity: 0, y: 30 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true },
  transition: { duration: 0.6 },
};

export default function HomePage() {
  return (
    <>
      {/* Hero */}
      <section className="relative min-h-[90vh] flex items-center overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${HERO_IMAGE})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-navy-950/95 via-navy-950/75 to-navy-950/40" />
        <div className="absolute top-20 right-0 w-96 h-96 opacity-10">
          <svg viewBox="0 0 200 200" className="w-full h-full text-gold-400">
            <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
              <path d="M 20 0 L 0 0 0 20" fill="none" stroke="currentColor" strokeWidth="0.5" />
            </pattern>
            <rect width="200" height="200" fill="url(#grid)" />
          </svg>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 w-full">
          <motion.div {...fadeUp}>
            <p className="text-gold-400 text-xs font-semibold uppercase tracking-[0.25em] mb-4">
              Welcome To
            </p>
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white uppercase leading-tight max-w-4xl">
              Turtle Shell Mortgage Partners
            </h1>
            <p className="text-gold-400 text-lg md:text-xl font-medium uppercase tracking-wide mt-4">
              Your Destiny, By Your Own Design
            </p>
            <p className="text-white/80 text-base md:text-lg mt-6 max-w-2xl leading-relaxed">
              Your Mortgage. Your Future. Your Choice. Mortgage solutions designed around your goals.
              Buying a home is one of the biggest financial decisions you&apos;ll make — we help make
              the process easier to understand and easier to navigate.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Button to="/contact">Get Started</Button>
              <Button to="/how-it-works" variant="secondary" className="gap-2">
                <span className="w-8 h-8 rounded-full border-2 border-white flex items-center justify-center">
                  <Play className="w-3 h-3 fill-white ml-0.5" />
                </span>
                How It Works
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* What Are You Looking To Do */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading
            label="Get Started"
            title="What Are You Looking To Do?"
            className="mb-14"
          />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {homeGoals.map((goal, i) => {
              const Icon = iconMap[goal.icon];
              return (
                <motion.div key={goal.title} {...fadeUp} transition={{ delay: i * 0.1 }}>
                  <GoalCard
                    icon={Icon}
                    title={goal.title}
                    description={goal.description}
                    to={goal.link}
                  />
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Mortgage Guidance Made Simple */}
      <section className="py-20 bg-cream-100">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div {...fadeUp}>
            <SectionHeading
              label="Mortgage Guidance Made Simple"
              title="A Mortgage Doesn't Have To Be Complicated"
            />
            <div className="mt-8 space-y-4 text-gray-600 leading-relaxed">
              <p>
                There are many mortgage options, requirements, rates, terms, and documents to
                understand. It can quickly become overwhelming.
              </p>
              <p>That&apos;s where Turtle Shell Mortgage Partners comes in.</p>
              <p>
                We take the time to understand your goals, explain your options clearly, and guide
                you through the mortgage journey from your first conversation to the next step.
              </p>
              <p className="text-navy-950 font-bold text-lg pt-4">
                Clear Advice. Personal Service. Confident Decisions.
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Our Services */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading
            label="Our Services"
            title="Mortgage Solutions Designed For You"
            className="mb-14"
          />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <ServiceCard
              icon={Home}
              title="Home Purchase Loans"
              description="Make your dream home a reality with competitive rates and flexible terms tailored to your needs."
            />
            <ServiceCard
              icon={RefreshCw}
              title="Refinance Solutions"
              description="Lower your monthly payments and save more with refinancing options aligned to your current goals."
            />
            <ServiceCard
              icon={BarChart3}
              title="Investment Property Loans"
              description="Grow your wealth with smart financing for your investment properties."
            />
            <ServiceCard
              icon={UserCheck}
              title="Personalized Guidance"
              description="Expert advice every step of the way to help you make confident decisions."
            />
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-navy-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div {...fadeUp} className="relative">
              <img
                src={FAMILY_IMAGE}
                alt="Family reviewing mortgage options"
                className="rounded-lg w-full h-[400px] object-cover"
              />
              <div className="absolute -bottom-6 -right-4 md:right-6 bg-navy-900 border border-gold-400/20 rounded-lg p-5 shadow-xl max-w-xs">
                <div className="flex items-center gap-3">
                  <Shield className="w-8 h-8 text-gold-400" />
                  <p className="text-white text-sm font-semibold">
                    Trusted. Transparent. Customer Focused.
                  </p>
                </div>
              </div>
            </motion.div>

            <motion.div {...fadeUp}>
              <p className="text-gold-400 text-xs font-semibold uppercase tracking-[0.2em] mb-3">
                Why Choose Us
              </p>
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
                Your Goals, Our Priority
              </h2>
              <p className="text-white/70 mb-8 leading-relaxed">
                Why Choose Turtle Shell Mortgage Partners? We believe every client deserves
                personalized guidance, clear communication, and support throughout their mortgage
                journey.
              </p>
              <div className="space-y-5">
                {whyChooseFeatures.slice(0, 3).map((feature) => (
                  <FeatureItem key={feature.title} {...feature} />
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading label="How It Works" title="A Clear Path Forward" className="mb-14" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {howItWorksSteps.map((step, i) => (
              <motion.div key={step.title} {...fadeUp} transition={{ delay: i * 0.1 }}>
                <StepCard {...step} />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Mortgage Solutions For Every Stage */}
      <section className="py-20 bg-cream-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading
            label="Our Solutions"
            title="Mortgage Solutions For Every Stage"
            className="mb-14"
          />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {mortgageSolutions.map((solution, i) => (
              <motion.div
                key={solution.title}
                {...fadeUp}
                transition={{ delay: i * 0.05 }}
                className="bg-white rounded-lg p-6 shadow-sm border border-gray-100"
              >
                <h3 className="text-navy-950 font-bold mb-2">{solution.title}</h3>
                <p className="text-gray-600 text-sm leading-relaxed">{solution.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Turtle Shell */}
      <section className="py-20 bg-navy-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading
            label="Why Turtle Shell?"
            title="Protection. Stability. Confidence."
            light
            className="mb-6"
          />
          <p className="text-white/70 text-center max-w-2xl mx-auto mb-14 leading-relaxed">
            A turtle&apos;s shell represents protection and security. Those values are at the heart of
            our approach.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {turtleValues.map((value, i) => (
              <motion.div key={value.title} {...fadeUp} transition={{ delay: i * 0.1 }}>
                <ValueCard icon={Shield} {...value} />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <CTABanner />

      <CTASection
        title="Ready To Take The Next Step?"
        description="You don't need to have everything figured out before you contact us. Tell us what you're looking to achieve, and let's explore your mortgage options together."
        primaryText="Get Started"
        secondaryText="Book A Consultation"
        primaryTo="/contact"
        secondaryTo="/contact"
      />
    </>
  );
}
