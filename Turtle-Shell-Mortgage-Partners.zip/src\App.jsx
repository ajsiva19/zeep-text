import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Layout } from "./components/layout/Layout";
import HomePage from "./pages/Home";
import AboutPage from "./pages/About";
import ServicesPage from "./pages/Services";
import FirstTimeBuyersPage from "./pages/FirstTimeBuyers";
import HowItWorksPage from "./pages/HowItWorks";
import FAQPage from "./pages/FAQ";
import ContactPage from "./pages/Contact";
import KnowledgeHubPage from "./pages/KnowledgeHub";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<Layout />}>
          <Route path="/" element={<HomePage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/services" element={<ServicesPage />} />
          <Route path="/first-time-buyers" element={<FirstTimeBuyersPage />} />
          <Route path="/how-it-works" element={<HowItWorksPage />} />
          <Route path="/faq" element={<FAQPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/knowledge-hub" element={<KnowledgeHubPage />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
